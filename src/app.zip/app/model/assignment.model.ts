export interface AssignmentModel {
  id: number;
  title: string;
  description: string;
  dueDate: string;
}
