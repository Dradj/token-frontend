export interface User {
  id: number;
  email: string;
  firstName: string;
  middleName: string;
  lastName: string;
  role: string;
  groupId: number;
}


