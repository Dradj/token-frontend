export interface SubmittedAssignment {
  submissionId: number;
  assignmentId: number;
  downloadUrl: string;
  fileName: string;
  submittedAt: string;
}

